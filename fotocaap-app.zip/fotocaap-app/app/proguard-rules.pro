# تنظیمات پایه ProGuard/R8 برای Release
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# WebView JavaScript interface (در صورت افزودن در آینده)
# -keepclassmembers class ir.fotocaap.app.* {
#     public *;
# }
