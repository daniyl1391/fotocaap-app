package ir.fotocaap.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import ir.fotocaap.app.databinding.ActivityMainBinding

/**
 * صفحه اصلی برنامه: نمایش سایت fotocaap.ir داخل WebView امن.
 *
 * اصول امنیتی رعایت‌شده:
 * - فقط دامنه‌های مجاز (ALLOWED_HOSTS) باز می‌شوند؛ لینک به سایت دیگر داخل مرورگر خارجی باز می‌شود.
 * - خطای SSL هرگز نادیده گرفته نمی‌شود (onReceivedSslError -> cancel).
 * - addJavascriptInterface استفاده نشده است.
 * - دانلود/اجرای فایل APK از داخل WebView مسدود است.
 * - آپلود عکس/فایل از طریق onShowFileChooser با ActivityResult پشتیبانی می‌شود.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        // TODO: وقتی کارفرما لیست کامل دامنه‌های سرویس OTP/نتایج زنده را داد، اینجا اضافه شود
        // (و هم‌زمان در network_security_config.xml هم باید اضافه شوند).
        private val ALLOWED_HOSTS = listOf("fotocaap.ir")
        private const val HOME_URL = "https://fotocaap.ir/"
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val results: Array<Uri>? = if (result.resultCode == RESULT_OK && data?.data != null) {
            arrayOf(data.data!!)
        } else null
        filePathCallback?.onReceiveValue(results)
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWebView()
        setupBackNavigation()
        setupSwipeRefresh()

        binding.btnRetry.setOnClickListener {
            binding.noInternetLayout.visibility = View.GONE
            binding.webView.reload()
        }

        if (savedInstanceState == null) {
            binding.webView.loadUrl(HOME_URL)
        }
    }

    private fun setupWebView() {
        val webView: WebView = binding.webView
        val settings: WebSettings = webView.settings

        // فقط تنظیمات حداقلی موردنیاز برای کارکرد صحیح سایت
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true // برای Session/Login سمت کلاینت لازم است
        settings.setSupportZoom(false)
        settings.builtInZoomControls = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        // کوکی‌ها برای حفظ Login/Session
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, false)

        // هیچ addJavascriptInterface ای اضافه نشده است.

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url
                val host = url.host ?: return true

                val isAllowed = ALLOWED_HOSTS.any { allowed ->
                    host == allowed || host.endsWith(".$allowed")
                }

                // مسدودسازی دانلود/اجرای فایل APK از هر منبعی
                if (url.toString().endsWith(".apk", ignoreCase = true)) {
                    return true // بارگذاری نشود
                }

                return if (isAllowed) {
                    false // داخل همین WebView باز شود
                } else {
                    // لینک به دامنه خارجی: در مرورگر پیش‌فرض گوشی باز شود
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, url))
                    } catch (_: Exception) {
                    }
                    true
                }
            }

            override fun onReceivedSslError(
                view: WebView,
                handler: SslErrorHandler,
                error: SslError
            ) {
                // خطای SSL هرگز نادیده گرفته نمی‌شود
                handler.cancel()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(getString(R.string.ssl_error_title))
                    .setMessage(error.toString())
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                binding.swipeRefresh.isRefreshing = false
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    binding.noInternetLayout.visibility = View.VISIBLE
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // پشتیبانی از آپلود عکس/فایل موردنیاز سایت (مثلاً input type=file)
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                filePathCallback = callback
                val intent = fileChooserParams.createIntent().apply {
                    type = "image/*"
                }
                fileChooserLauncher.launch(Intent.createChooser(intent, null))
                return true
            }
        }

        // دانلود مستقیم فایل (غیر از APK که در بالا مسدود شد) در مرورگر خارجی باز شود
        webView.setDownloadListener { url, _, _, _, _ ->
            if (!url.endsWith(".apk", ignoreCase = true)) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            binding.webView.reload()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        binding.webView.restoreState(savedInstanceState)
    }
}
