package ir.fotocaap.app

import android.app.Application

class FotocaapApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // در این کلاس هیچ SDK تبلیغاتی، آنالیتیکس یا ردیاب شخص‌ثالثی مقداردهی نمی‌شود.
    }
}
