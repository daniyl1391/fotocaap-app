package ir.fotocaap.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import ir.fotocaap.app.databinding.ActivitySplashBinding

/**
 * اسپلش اسکرین: پس‌زمینه مشکی، توپ فوتبال بالا و پایین می‌رود،
 * حدود ۱.۵ ثانیه بعد صفحه اصلی (ورود سایت) باز می‌شود.
 */
class SplashActivity : AppCompatActivity() {

    private val splashDurationMs = 1500L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bounce = ObjectAnimator.ofFloat(
            binding.ivSplashBall, "translationY", 0f, -80f, 0f
        ).apply {
            duration = 500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = AccelerateDecelerateInterpolator()
        }
        bounce.start()

        Handler(Looper.getMainLooper()).postDelayed({
            bounce.cancel()
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, splashDurationMs)
    }
}
