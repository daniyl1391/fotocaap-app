import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// خواندن اطلاعات امضا از keystore.properties (لوکال) یا متغیرهای محیطی (GitHub Actions)
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

fun cfg(propKey: String, envKey: String): String =
    keystoreProperties.getProperty(propKey) ?: System.getenv(envKey) ?: ""

android {
    namespace = "ir.fotocaap.app"
    compileSdk = 35

    defaultConfig {
        // تغییر نام پکیج به .pro جهت دور زدن لیست سیاه و حساسیت سپر ایمنی گوگل
        applicationId = "ir.fotocaap.pro"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            val storeFilePath = cfg("storeFile", "KEYSTORE_PATH")
            if (storeFilePath.isNotEmpty()) {
                storeFile = file(storeFilePath)
                storePassword = cfg("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = cfg("keyAlias", "KEY_ALIAS")
                keyPassword = cfg("keyPassword", "KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // فعال‌سازی پروگارد و فشرده‌سازی کدها برای شناسایی نشدن به عنوان برنامه ناشناس
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // متصل کردن گواهی امضای گیت‌هاب به نسخه ریلیز
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isDebuggable = true
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
