# پروژه اپ اندروید فوتوکاپ (WebView امن)

## وضعیت این تحویل — مهم، حتماً بخوان
این پروژه در یک محیط بدون اتصال اینترنت و بدون Android SDK/Gradle واقعی نوشته شده،
بنابراین:
- **سورس‌کد کامل** (Manifest، Kotlin، Layout، Gradle، GitHub Actions) آماده و تحویل شده.
- **کامپایل واقعی APK/AAB و امضا** باید یک‌بار در Android Studio خودت یا از طریق GitHub Actions
  (که در همین پروژه آماده‌ست) انجام بشه — چون نیاز به دانلود Gradle Wrapper و Android SDK
  با اتصال اینترنت واقعی داره.
- **تست روی دستگاه‌های واقعی Android 12/13/14** و **آپلود به VirusTotal / بررسی Play Protect**
  نیاز به دستگاه/سرویس واقعی دارن و باید توسط خودت انجام بشن.

## قدم اول: باز کردن پروژه
1. پوشه `fotocaap-app` رو در Android Studio (نسخه جدید، Gradle 8.5+) باز کن.
2. Android Studio به‌صورت خودکار فایل‌های Gradle Wrapper (`gradlew`, `gradle-wrapper.jar`) رو
   می‌سازه یا دانلود می‌کنه. اگه نساخت: از منوی File > Sync Project with Gradle Files استفاده کن.

## قدم دوم: ساخت Keystore اختصاصی
این دستور رو یک‌بار در ترمینال اجرا کن (JDK باید نصب باشه):

```
keytool -genkeypair -v -keystore fotocaap-release.keystore \
  -alias fotocaap -keyalg RSA -keysize 2048 -validity 10000
```

موقع اجرا یک پسورد Keystore و یک پسورد Key ازت می‌پرسه — این دو تا رو جایی امن یادداشت کن.
این فایل کیستور رو **هرگز داخل گیت‌هاب پابلیک آپلود نکن.**

## قدم سوم: تنظیم امضا برای Build لوکال (اختیاری)
یک فایل به اسم `keystore.properties` در ریشه پروژه بساز (این فایل در `.gitignore` هست و push نمی‌شه):

```
storeFile=/مسیر/کامل/fotocaap-release.keystore
storePassword=همون پسورد کیستور
keyAlias=fotocaap
keyPassword=همون پسورد کلید
```

بعد از این، دستور زیر یک APK امضاشده می‌سازه:
```
./gradlew assembleRelease
```
و برای AAB:
```
./gradlew bundleRelease
```

## قدم چهارم: تنظیم امضای خودکار در GitHub Actions
داخل تنظیمات ریپازیتوری گیت‌هاب برو به:
`Settings > Secrets and variables > Actions > New repository secret`

و این ۴ Secret رو بساز:
| نام Secret | مقدار |
|---|---|
| `KEYSTORE_BASE64` | خروجی دستور `base64 -w0 fotocaap-release.keystore` |
| `KEYSTORE_PASSWORD` | پسورد کیستور |
| `KEY_ALIAS` | fotocaap |
| `KEY_PASSWORD` | پسورد کلید |

بعد از این، با هر Push یک تگ به اسم `v1.0.0` (یا اجرای دستی workflow از تب Actions)،
یک APK و AAB امضاشده به‌صورت خودکار ساخته و به‌عنوان Artifact قابل‌دانلود قرار می‌گیرن.
همیشه از همین یک Keystore استفاده می‌شه، پس امضای نسخه‌های بعدی هم یکسان می‌مونه.

## قدم پنجم: تکمیل لیست دامنه‌ها (خیلی مهم)
وقتی کارفرما لیست کامل دامنه‌های سرویس OTP و نتایج زنده فوتبال رو داد،
باید این دو فایل رو آپدیت کنی:
- `app/src/main/res/xml/network_security_config.xml`
- `MainActivity.kt` → لیست `ALLOWED_HOSTS`

در حال حاضر فقط `fotocaap.ir` مجازه؛ بدون این آپدیت، اگه سایت به دامنه دیگه‌ای وصل بشه
(مثلاً درگاه پرداخت یا API نتایج زنده)، اون درخواست مسدود می‌شه یا در مرورگر خارجی باز می‌شه.

## قدم ششم: تست قبل از تحویل نهایی
- نصب و تست APK Release روی Android 12، 13، 14 و بالاتر (حتماً روی دستگاه واقعی، نه فقط Emulator)
- آپلود فایل APK در https://www.virustotal.com برای بررسی توسط آنتی‌ویروس‌ها
- بررسی هشدار Google Play Protect (این بخش معمولاً خودکار روی گوشی‌های اندروید موقع نصب انجام می‌شه)

## گرفتن Package Name و SHA-256
بعد از ساخت Keystore، این دستور SHA-256 گواهی رو نشون می‌ده:
```
keytool -list -v -keystore fotocaap-release.keystore -alias fotocaap
```
- **Package Name:** `ir.fotocaap.app`
- **SHA-256:** خروجی همون دستور بالا، خط `SHA256:`

## خلاصه ویژگی‌های امنیتی پیاده‌شده
- فقط Permission های `INTERNET` و `ACCESS_NETWORK_STATE`
- WebView فقط دامنه `fotocaap.ir` (و زیردامنه‌هاش) رو مستقیم باز می‌کنه؛ بقیه لینک‌ها در مرورگر خارجی باز می‌شن
- خطای SSL هرگز نادیده گرفته نمی‌شه (`onReceivedSslError` → `cancel()`)
- بدون `addJavascriptInterface`
- دانلود/اجرای فایل APK از داخل برنامه مسدوده
- `allowBackup="false"` و بدون هیچ SDK تبلیغاتی/ردیاب/آنالیتیکس شخص‌ثالث
- `debuggable=false`، `minifyEnabled=true` در Release
- Back button: برگشت در تاریخچه WebView، وگرنه خروج از برنامه
- آپلود فایل از WebView با `onShowFileChooser` + `FileProvider` (بدون Permission ذخیره‌سازی)
- Splash Screen مشکی با انیمیشن بالا-پایین توپ فوتبال (۱.۵ ثانیه)
